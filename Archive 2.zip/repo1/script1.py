import os
import subprocess
import sys

# Define the paths to the repository directories and README.md file
REPO1_DIR = os.path.join(os.path.dirname(__file__), "test_project_3")
README_FILE = "README.md"
REMOTE_NAME = "origin"
BRANCH_NAME = "main"

def run_command(command, cwd=None):
    """Run a command and return the output."""
    print(f"Running command: {' '.join(command)} in directory: {cwd}")
    result = subprocess.run(command, cwd=cwd, text=True, capture_output=True)
    if result.returncode != 0:
        print(f"Command failed with error code {result.returncode}")
        print(f"Command: {' '.join(command)}")
        print(f"Output: {result.stdout}")
        print(f"Error: {result.stderr}")
        if result.stderr:
            print(f"Detailed Error: {result.stderr.strip()}")
        raise subprocess.CalledProcessError(result.returncode, command)
    return result.stdout

def format_commit_message(message):
    """Format the commit message as a single string."""
    return message

def write_to_readme(repo_dir, text):
    """Write the provided text to the README.md file after the [INTRANET] tag."""
    readme_path = os.path.join(repo_dir, README_FILE)
    with open(readme_path, 'r+') as file:
        content = file.read()
        updated_content = content.replace("[INTRANET]", f"[INTRANET]\n{text}")
        file.seek(0)
        file.write(updated_content)
        file.truncate()
    print(f"Added text to {README_FILE} in {repo_dir}: {text}")

def resolve_conflict_and_commit(repo_dir, readme_file):
    """Resolve the conflict in README.md by combining both changes and commit."""
    with open(readme_file, 'r+') as file:
        content = file.read()

        if "<<<<<<< HEAD" in content:
            print(f"Handling conflict in {readme_file}")
            ours = content.split("<<<<<<< HEAD")[1].split("=======")[0].strip()
            theirs = content.split("=======")[1].split(">>>>>>>")[0].strip()

            # Combine both changes with a separator or custom formatting
            resolved_content = f"{ours}\n\n# Combined Conflict Resolution\n\n{theirs}"
            final_content = content.split("<<<<<<< HEAD")[0] + resolved_content + content.split(">>>>>>>")[1]

            file.seek(0)
            file.write(final_content)
            file.truncate()

    # Stage the resolved file and commit
    try:
        run_command(["git", "add", README_FILE], cwd=repo_dir)
        commit_message = format_commit_message(f"Merged {README_FILE} conflicts with custom logic")
        run_command(["git", "commit", "-m", commit_message], cwd=repo_dir)
        print(f"Successfully resolved conflicts and committed in {repo_dir}")
    except subprocess.CalledProcessError as e:
        print(f"Failed to resolve conflicts and commit in {repo_dir}: {e}")
        raise

def check_file_exists(file_path):
    """Check if a file exists at the given path."""
    return os.path.isfile(file_path)

def commit_and_push(repo_dir, branch_name, text_to_add):
    """Commit the changes to the README.md file and push them to the remote repository."""
    readme_path = os.path.join(repo_dir, README_FILE)
    
    if not check_file_exists(readme_path):
        print(f"{README_FILE} not found in {repo_dir}")
        return

    # Write to the README.md file
    write_to_readme(repo_dir, text_to_add)
    commit_message = format_commit_message("Add text to README.md")
    try:
        # Check the current git status before adding
        run_command(["git", "status"], cwd=repo_dir)

        # Stage the changes
        run_command(["git", "add", README_FILE], cwd=repo_dir)

        # Check if there are changes to commit
        status_output = run_command(["git", "status", "--porcelain"], cwd=repo_dir)
        if status_output.strip():
            run_command(["git", "commit", "-m", commit_message], cwd=repo_dir)
        else:
            print("No changes to commit.")

        # Pull the latest changes from the remote, specify how to handle divergent branches
        run_command(["git", "pull", "--rebase=false", REMOTE_NAME, branch_name], cwd=repo_dir)

        # Push the changes
        run_command(["git", "push", REMOTE_NAME, branch_name], cwd=repo_dir)
        print(f"Committed and pushed changes to {REMOTE_NAME}/{branch_name}")

    except subprocess.CalledProcessError as e:
        print(f"Error during pull or push: {e}")
        if "CONFLICT" in str(e.stderr):
            print("Merge conflict detected. Applying custom merge logic...")
            resolve_conflict_and_commit(repo_dir, readme_path)
            run_command(["git", "push", REMOTE_NAME, branch_name], cwd=repo_dir)
        else:
            print("Error was not related to conflicts. Exiting.")
            raise

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python script.py <text_to_add>")
        sys.exit(1)

    text_to_add = sys.argv[1]
    commit_and_push(REPO1_DIR, BRANCH_NAME, text_to_add)
