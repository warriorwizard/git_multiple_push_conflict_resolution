import os
import sys
import subprocess

def clone_repo():
    if os.path.exists("test_project"):
        # Don't clone if directory already exists
        print("Repo already cloned")
    else:
        print("Cloning the repo")
        result = subprocess.run(["git", "clone", "https://github.com/warriorwizard/test_project.git"], capture_output=True, text=True)
        if result.returncode != 0:
            print(f"Error cloning repository: {result.stderr}")
            sys.exit(1)

def write_to_file():
    file_path = os.path.join(os.getcwd(), "test_project", "test_ntnx.txt")
    print(file_path)
    try:
        with open(file_path, "r+") as file:
            lines = file.readlines()
            for i, line in enumerate(lines):
                if line.strip() == "[INTRANET]":
                    lines.insert(i + 1, sys.argv[1] + "\n")
                    break
            file.seek(0)
            file.writelines(lines)
            file.truncate()
    except FileNotFoundError:
        print(f"File not found: {file_path}")
        sys.exit(1)
    except Exception as e:
        print(f"Error writing to file: {e}")
        sys.exit(1)

def create_or_switch_branch(branch_name):
    # Check if the branch exists locally
    result = subprocess.run(["git", "branch", "--list", branch_name], capture_output=True, text=True)
    
    if result.stdout.strip():
        print(f"Branch '{branch_name}' already exists.")
        print(f"Switching to branch '{branch_name}'.")
        subprocess.run(["git", "checkout", branch_name], check=True)
    else:
        print(f"Creating branch '{branch_name}'.")
        subprocess.run(["git", "checkout", "-b", branch_name], check=True)
    
    # Check if the branch exists on the remote
    result = subprocess.run(["git", "ls-remote", "--heads", "origin", branch_name], capture_output=True, text=True)
    if not result.stdout.strip():
        print(f"Pushing branch '{branch_name}' to remote and setting upstream.")
        subprocess.run(["git", "push", "--set-upstream", "origin", branch_name], check=True)

def commit_push():
    os.chdir("test_project")
    
    # Create or switch to 'branch1'
    create_or_switch_branch("branch1")

    # Try pulling from the remote branch with a strategy
    print("Pulling changes from remote branch 'branch1'.")
    result = subprocess.run(["git", "pull", "--no-rebase", "origin", "branch1"], capture_output=True, text=True)
    if result.returncode != 0:
        if "conflict" in result.stderr.lower():
            print("Merge conflict detected! Resolve conflicts before pushing.")
        else:
            print(f"Error pulling changes: {result.stderr}")
        sys.exit(1)

    # Stage all changes
    subprocess.run(["git", "add", "."], check=True)
    
    # Commit changes
    subprocess.run(["git", "commit", "-m", "Added new entry"], check=True)
    
    # Push changes
    result = subprocess.run(["git", "push", "--set-upstream", "origin", "branch1" ], capture_output=True, text=True)
    
    if result.returncode != 0:
        if "conflict" in result.stderr.lower():
            print("Merge conflict detected! Resolve conflicts before pushing.")
        else:
            print(f"Error pushing changes: {result.stderr}")
        sys.exit(1)
    
    print("=========Done=========")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python script.py <text-to-write>")
        sys.exit(1)

    clone_repo()
    write_to_file()
    commit_push()
