import os
import sys
import subprocess

def clone_repo():
    if os.path.exists("test_project"):
        # Don't clone if directory already exists
        print("Repo already cloned")
    else:
        print("Cloning the repo")
        result = subprocess.run(["git", "clone", "https://github.com/warriorwizard/test_project.git"], capture_output=True, text=True)
        if result.returncode != 0:
            print(f"Error cloning repository: {result.stderr}")
            sys.exit(1)

def write_to_file():
    file_path = os.path.join(os.getcwd(), "test_project", "test_ntnx.txt")
    print(file_path)
    try:
        with open(file_path, "r+") as file:
            lines = file.readlines()
            for i, line in enumerate(lines):
                if line.strip() == "[INTRANET]":
                    lines.insert(i + 1, sys.argv[1] + "\n")
                    break
            file.seek(0)
            file.writelines(lines)
            file.truncate()
    except FileNotFoundError:
        print(f"File not found: {file_path}")
        sys.exit(1)
    except Exception as e:
        print(f"Error writing to file: {e}")
        sys.exit(1)

def commit_push():
    os.chdir("test_project")
    
    # Ensure we're on the 'main' branch
    subprocess.run(["git", "checkout", "main"], check=True)
    
    # Pull the latest changes from the remote 'main' branch
    result = subprocess.run(["git", "pull", "origin", "main"], capture_output=True, text=True)
    if result.returncode != 0:
        if "conflict" in result.stderr.lower():
            print("Merge conflict detected! Resolve conflicts before pushing.")
        else:
            print(f"Error pulling changes: {result.stderr}")
        sys.exit(1)
    
    # Stage all changes
    subprocess.run(["git", "pull"], check=True)
    subprocess.run(["git", "add", "."], check=True)
    subprocess.run(["git", "commit", "-m", "Added new entry"], check=True)
    result = subprocess.run(["git", "push", "origin", "main"], capture_output=True, text=True)
    
    if result.returncode != 0:
        if "conflict" in result.stderr.lower():
            print("Merge conflict detected! Resolve conflicts before pushing.")
            print(f"Error pushing changes: {result.stderr}")
        sys.exit(1)
    
    print("=========Done=========")

def merge_branches(source_branch, target_branch):
    # os.chdir("test_project")

    # Fetch latest branches from remote
    print("Fetching latest branches from remote.")
    result = subprocess.run(["git", "fetch"], capture_output=True, text=True)
    if result.returncode != 0:
        print(f"Error fetching from remote: {result.stderr}")
        sys.exit(1)

    # Checkout the target branch
    print(f"Switching to branch '{target_branch}' for merging.")
    result = subprocess.run(["git", "checkout", target_branch], capture_output=True, text=True)
    if result.returncode != 0:
        print(f"Error switching to branch '{target_branch}': {result.stderr}")
        sys.exit(1)
    
    # Merge the source branch into the target branch
    print(f"Merging branch '{source_branch}' into '{target_branch}'.")
    result = subprocess.run(["git", "merge", f"origin/{source_branch}"], capture_output=True, text=True)
    if result.returncode != 0:
        if "conflict" in result.stderr.lower():
            print("Merge conflict detected! Please resolve conflicts manually.")
            print(f"Merge conflict details: {result.stderr}")
            sys.exit(1)
        else:
            print(f"Error merging branches: {result.stderr}")
            sys.exit(1)
    
    print("Merge completed successfully.")
    # Push changes to remote branch
    result = subprocess.run(["git", "push", "origin", target_branch], capture_output=True, text=True)
    if result.returncode != 0:
        print(f"Error pushing changes to '{target_branch}': {result.stderr}")
        sys.exit(1)



if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python script.py <text-to-write>")
        sys.exit(1)


    source_branch =  "branch1" #sys.argv[1]
    target_branch = "main" #sys.argv[2]
    
    clone_repo()
    write_to_file()
    commit_push()
    merge_branches(source_branch, target_branch)
